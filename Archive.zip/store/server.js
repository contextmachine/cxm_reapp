export const globalUrl = "https://mmodel.contextmachine.online:8181/";
