export const globalUrl =
  /* "https://mmodel.contextmachine.online:8181/" */ "https://cdn.contextmachine.online/";
export const appProdUrl = "https://cxm-reapp.vercel.app/";
