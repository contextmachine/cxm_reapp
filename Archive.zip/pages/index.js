import Account from "./account";

export default function Home() {
  return <Account />;
}
